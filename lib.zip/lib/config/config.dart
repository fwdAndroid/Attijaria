import 'package:flutter/material.dart';

var dec = BoxDecoration(
  color: Color(0xffDFA600),
  image: DecorationImage(
      image: AssetImage('asset/overlay.png'), fit: BoxFit.cover),
);
