import 'package:flutter/material.dart';

Color primaryColor = Color(0xffd4d181);
Color textColor = Colors.black87;
